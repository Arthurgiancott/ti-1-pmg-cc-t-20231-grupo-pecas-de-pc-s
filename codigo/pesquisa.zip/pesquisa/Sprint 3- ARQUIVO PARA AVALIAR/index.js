onload = () => {
    preencherDadosTabela();
    preencherCategorias();
}

async function preencherDadosTabela() {
    var tblProdutos = document.getElementById('tblProdutos');
    var tbody = tblProdutos.querySelector('tbody');

    while (tbody.firstChild) {
        tbody.removeChild(tbody.firstChild);
    }

    var ddlPaginacao = document.getElementById('ddlPaginacao');
    let tamanhoPagina = 0;
    if (ddlPaginacao.value !== '') {
        tamanhoPagina = ddlPaginacao.value;
    }
    else {
        tamanhoPagina = 20;
    }
    
    const response = await fetch('https://fakestoreapi.com/products?limit=' + tamanhoPagina)
    let dados = await response.json();

    const dropdown = document.getElementById('ddlCategoria');
    if (dropdown.value !== '') {
        const categoria = dropdown.value.toLowerCase();
        dados = dados.filter(c => c.category.toLowerCase().includes(categoria));
    }

    const input = document.getElementById('Nome do Produto');
    if (input.value !== '') {
        const NomedoProduto = input.value.toLowerCase();
        dados = dados.filter(c => c.title.toLowerCase().includes(NomedoProduto));
    }

    dados.forEach(function (objeto) {
        var linha = document.createElement('tr');

        var colunaNomedoProduto = document.createElement('td');
        colunaNomedoProduto.textContent = objeto.title;
        linha.appendChild(colunaNomedoProduto);

        var colunaPreco = document.createElement('td');
        colunaPreco.textContent = 'R$: ' + objeto.price;
        linha.appendChild(colunaPreco);

        var colunaCategoria = document.createElement('td');
        colunaCategoria.textContent = objeto.category;
        linha.appendChild(colunaCategoria);

        var colunaImagem = document.createElement('td');
        var imagem = document.createElement('img');
        imagem.src = objeto.image;
        imagem.width = 100;
        imagem.height = 100;
        colunaImagem.appendChild(imagem);
        linha.appendChild(colunaImagem);

        var colunaAcoes = document.createElement('td');
        linha.appendChild(colunaAcoes);

        tbody.appendChild(linha);
    });
}

async function filtrarProdutos() {
    preencherDadosTabela();
}

async function preencherCategorias() {
    const dropdown = document.getElementById('ddlCategoria')
    const response = await fetch('https://fakestoreapi.com/products/categories')
    const dados = await response.json();
    dados.forEach(function (objeto) {
        const option = document.createElement('option');
        option.text = objeto;
        option.value = objeto;
        dropdown.add(option);
    });
}