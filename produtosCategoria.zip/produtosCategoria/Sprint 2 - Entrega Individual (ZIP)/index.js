let produtos = [];

onload = () => {
    if (JSON.parse(localStorage.getItem("produtos")) != null) {
        produtos = JSON.parse(localStorage.getItem("produtos"));
        preencherDadosTabela();
    }
}

function salvar() {
    var codigo = document.getElementById('codigo').value;
    var nome = document.getElementById('nome').value;
    var categoria = document.getElementById('categoria').value;
    var fornecedor = document.getElementById('fornecedor').value;
    var preco = document.getElementById('preco').value;
    var estoque = document.getElementById('estoque').value;

    produtos.push({
        codigo: codigo,
        nome: nome,
        categoria: categoria,
        fornecedor: fornecedor,
        preco: preco,
        estoque: estoque
    });

    localStorage.setItem('produtos', JSON.stringify(produtos));

    limparCampos();
    preencherDadosTabela();
    esconderDadosProdutos();
}

function excluir() {
    var codigoRemocao = document.getElementById('codigo').value;

    if (codigoRemocao === null) {
        alert('Informe o código por favor');
        return;
    }

    var indiceRemocao = -1;
    for (var i = 0; i < produtos.length; i++) {
        if (produtos[i].codigo === codigoRemocao) {
            indiceRemocao = i;
            break;
        }
    }

    if (indiceRemocao !== -1) {
        produtos.splice(indiceRemocao, 1);
        localStorage.setItem('produtos', JSON.stringify(produtos));

        limparCampos();
        preencherDadosTabela();
        esconderDadosProdutos();
    }
    else {
        alert('O produto com o código informado não existe.')
    }
}

function mostrarDadosProdutos() {
    var divListagemProdutos = document.getElementById('divListagemProduto');
    var divDadosProduto = document.getElementById('divDadosProduto');
    var btnSave = document.getElementById('btnSave');
    var btnUpdate = document.getElementById('btnUpdate');
    var btnCancel = document.getElementById('btnCancel');
    var btnDelete = document.getElementById('btnDelete');


    limparCampos();
    divListagemProdutos.style.display = 'none';
    divDadosProduto.style.display = 'block';

    btnSave.style.display = 'inline';
    btnUpdate.style.display = 'none';
    btnCancel.style.display = 'inline';
    btnDelete.style.display = 'none';
}

function esconderDadosProdutos() {
    var divListagemProdutos = document.getElementById('divListagemProduto');
    var divDadosProduto = document.getElementById('divDadosProduto');

    divListagemProdutos.style.display = 'block';
    divDadosProduto.style.display = 'none';
}

function limparCampos() {
    document.getElementById('codigo').value = '';
    document.getElementById('nome').value = '';
    document.getElementById('categoria').value = '';
    document.getElementById('fornecedor').value = '';
    document.getElementById('preco').value = '';
    document.getElementById('estoque').value = '';
}

function preencherDadosTabela() {
    var tblProdutos = document.getElementById('tblProdutos');
    var tbody = tblProdutos.querySelector('tbody');

    while (tbody.firstChild) {
        tbody.removeChild(tbody.firstChild);
    }

    produtos.forEach(function (objeto) {
        var linha = document.createElement('tr');

        var colunaCodigo = document.createElement('td');
        colunaCodigo.textContent = objeto.codigo;
        linha.appendChild(colunaCodigo);

        var colunaNome = document.createElement('td');
        colunaNome.textContent = objeto.nome;
        linha.appendChild(colunaNome);

        var colunaPreco = document.createElement('td');
        colunaPreco.textContent = objeto.preco;
        linha.appendChild(colunaPreco);

        var colunaAcoes = document.createElement('td');
        var botaoEditar = document.createElement('button');
        botaoEditar.textContent = 'Editar';
        botaoEditar.addEventListener('click', function () {
            mostrarDadosProdutosEdicao(objeto.codigo);
        });
        colunaAcoes.appendChild(botaoEditar);
        linha.appendChild(colunaAcoes);

        tbody.appendChild(linha);
    });
}

function mostrarDadosProdutosEdicao(codigo) {
    produtos = JSON.parse(localStorage.getItem("produtos"));

    var produtoEdicao = produtos.find(function (objeto) {
        return objeto.codigo === codigo;
    });

    document.getElementById('codigo').value = produtoEdicao.codigo;
    document.getElementById('nome').value = produtoEdicao.nome;
    document.getElementById('categoria').value = produtoEdicao.categoria;
    document.getElementById('fornecedor').value = produtoEdicao.fornecedor;
    document.getElementById('preco').value = produtoEdicao.preco;
    document.getElementById('estoque').value = produtoEdicao.estoque;

    var divListagemProdutos = document.getElementById('divListagemProduto');
    var divDadosProduto = document.getElementById('divDadosProduto');
    var btnSave = document.getElementById('btnSave');
    var btnUpdate = document.getElementById('btnUpdate');
    var btnCancel = document.getElementById('btnCancel');
    var btnDelete = document.getElementById('btnDelete');

    divListagemProdutos.style.display = 'none';
    divDadosProduto.style.display = 'block';

    btnSave.style.display = 'none';
    btnUpdate.style.display = 'inline';
    btnCancel.style.display = 'inline';
    btnDelete.style.display = 'inline';
}

function atualizar() {
    var codigo = document.getElementById('codigo').value;
    var nome = document.getElementById('nome').value;
    var categoria = document.getElementById('categoria').value;
    var fornecedor = document.getElementById('fornecedor').value;
    var preco = document.getElementById('preco').value;
    var estoque = document.getElementById('estoque').value;

    produtos = JSON.parse(localStorage.getItem("produtos"));

    var produtoAtualizacao = produtos.find(function (objeto) {
        return objeto.codigo === codigo;
    });

    if (produtoAtualizacao) {
        produtoAtualizacao.codigo = codigo;
        produtoAtualizacao.nome = nome;
        produtoAtualizacao.categoria = categoria;
        produtoAtualizacao.fornecedor = fornecedor;
        produtoAtualizacao.preco = preco;
        produtoAtualizacao.estoque = estoque;
    }

    localStorage.setItem('produtos', JSON.stringify(produtos));

    limparCampos();
    preencherDadosTabela();
    esconderDadosProdutos();
}