[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10814440&assignment_repo_type=AssignmentRepo)
# Nome do projeto
Escreva um ou dois  parágrafo resumindo o objetivo do seu projeto.

## Alunos integrantes da equipe

* Nome completo do aluno 1
* Nome completo do aluno 2
* Nome completo do aluno 3
* Nome completo do aluno 4

## Professores responsáveis

* Nome completo do professor 1
* Nome completo do professor 2

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
