// botao.js
const cadastroButton = document.querySelector('.button');
cadastroButton.addEventListener('click', () => {
  window.location.href = 'confirmação.html';
});

